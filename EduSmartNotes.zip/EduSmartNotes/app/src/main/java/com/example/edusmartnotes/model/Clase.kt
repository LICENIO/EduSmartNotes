package com.example.edusmartnotes.model

data class Clase(
    var nombre: String,
    var  horaInicio: String,
    var horaFin: String

)
