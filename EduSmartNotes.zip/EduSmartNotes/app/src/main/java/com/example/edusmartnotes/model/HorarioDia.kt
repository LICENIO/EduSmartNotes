package com.example.edusmartnotes.model

data class HorarioDia(
    val dia: String,
    val clases: MutableList<Clase> = mutableListOf()
)
