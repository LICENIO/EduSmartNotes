package com.example.edusmartnotes.model

data class Nota(
    val id: String = "",            // Identificador único de la nota
    val titulo: String = "",        // Título de la nota
    val descripcion: String = "",   // Descripción de la nota
    val fecha: String = "",          // Fecha de creación o modificación de la nota
    val importante: Boolean = false
)
