package com.example.edusmartnotes.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.edusmartnotes.screens.NoteImportScreen
import com.example.edusmartnotes.ui.theme.screens.AboutAppScreen
import com.example.edusmartnotes.ui.theme.screens.LoginScreen
import com.example.edusmartnotes.ui.theme.screens.RegisterScreen
import com.example.edusmartnotes.ui.theme.screens.HomeScreen
import com.example.edusmartnotes.ui.theme.screens.WelcomeScreen
import com.example.edusmartnotes.ui.theme.screens.AddNoteScreen
import com.example.edusmartnotes.ui.theme.screens.EditNoteScreen
import com.example.edusmartnotes.ui.theme.screens.HorarioScreen
import com.example.edusmartnotes.ui.theme.screens.ListNotesScreen
import com.example.edusmartnotes.ui.theme.screens.SettingsScreen
import com.example.edusmartnotes.viewmodel.NotesViewModel

@Composable
fun NavGraph(
    navController: NavHostController,
    isDarkTheme: Boolean, // Aceptamos el estado del tema como parámetro
    viewModel: NotesViewModel // Asegúrate de pasar el ViewModel para ListNotesScreen
){
    NavHost(
        navController = navController,
        startDestination = "welcome"
    ) {
        composable("welcome") {
            WelcomeScreen(navController = navController)
        }

        composable("login") {
            LoginScreen(
                navController = navController,
                onNavigateToHome = {
                    navController.navigate("home") {
                        popUpTo("welcome") { inclusive = false }
                    }
                },
                onNavigateToRegister = {
                    navController.navigate("register")
                }
            )
        }

        composable("register") {
            RegisterScreen(navController = navController) {
                navController.navigate("login")
            }
        }

        composable("home") {
            HomeScreen(navController)
        }

        composable("settings") {
            SettingsScreen(navController = navController)
        }

        composable(route = "horario") {
            HorarioScreen(navController = navController)
        }

        composable("addNote") {
            AddNoteScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        composable("listNotes") {
            ListNotesScreen(viewModel = viewModel, navController = navController)
        }

        composable("notasImportantes") {
            NoteImportScreen(viewModel = viewModel, navController = navController)
        }

        composable("acercaDeApp") {
            AboutAppScreen(navController = navController)
        }

        composable(
            route = "editNote/{notaId}",
            arguments = listOf(navArgument("notaId") { type = androidx.navigation.NavType.StringType })
        ) { backStackEntry ->
            val notaId = backStackEntry.arguments?.getString("notaId")
            if (notaId != null) {
                EditNoteScreen(viewModel = viewModel, navController = navController, notaId = notaId)
            }
        }

    }
}
