/*package com.example.edusmartnotes.navigation

object Routes {
    const val WELCOME = "welcome"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val HOME = "home"
    const val ADD_NOTE = "add_note"
    const val IMPORTANT_NOTES = "important_notes"
    const val SCHEDULE = "schedule"
    const val EXAM_NOTIFICATIONS = "exam_notifications"
    const val LIST_NOTES = "list_notes"
}*/