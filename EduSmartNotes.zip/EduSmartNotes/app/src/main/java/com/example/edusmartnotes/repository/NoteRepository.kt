package com.example.edusmartnotes.repository

import android.util.Log
import com.example.edusmartnotes.model.Nota
import com.google.firebase.firestore.FirebaseFirestore

class NoteRepository {

    private val db = FirebaseFirestore.getInstance()

    fun guardarNota(nota: Nota, onSuccess: () -> Unit, onFailure: (Exception) -> Unit) {
        val notaRef = db.collection("notas").document()
        val notaConId = nota.copy(id = notaRef.id) // Generar un ID único

        notaRef.set(notaConId)
            .addOnSuccessListener {
                onSuccess()
            }
            .addOnFailureListener { e ->
                Log.w("Firestore", "Error al guardar la nota", e)
                onFailure(e)
            }
    }

    // Método para obtener todas las notas
    fun getAllNotes(onResult: (List<Nota>) -> Unit, onFailure: (Exception) -> Unit) {
        db.collection("notas")
            .get()
            .addOnSuccessListener { result ->
                val notas = result.documents.mapNotNull { it.toObject(Nota::class.java) }
                onResult(notas)
            }
            .addOnFailureListener { e ->
                Log.w("Firestore", "Error al obtener las notas", e)
                onFailure(e)
            }
    }

    fun updateNote(nota: Nota, onSuccess: () -> Unit, onFailure: (Exception) -> Unit) {
        val notaRef = db.collection("notas").document(nota.id)

        notaRef.update("importante", nota.importante)
            .addOnSuccessListener {
                onSuccess() // Llamar al callback de éxito
            }
            .addOnFailureListener { e ->
                Log.w("Firestore", "Error al actualizar la nota", e)
                onFailure(e) // Llamar al callback de fallo
            }
    }

    fun toggleImportantStatus(notaId: String, onSuccess: () -> Unit, onFailure: (Exception) -> Unit) {
        val notaRef = db.collection("notas").document(notaId)

        // Obtener la nota, alternar el campo "importante" y actualizarla en Firestore
        notaRef.get()
            .addOnSuccessListener { document ->
                val nota = document.toObject(Nota::class.java)
                if (nota != null) {
                    val updatedNota = nota.copy(importante = !nota.importante) // Alternar "importante"
                    // Actualizar el campo "importante"
                    notaRef.update("importante", updatedNota.importante)
                        .addOnSuccessListener {
                            onSuccess()
                        }
                        .addOnFailureListener { e ->
                            onFailure(e)
                        }
                }
            }
            .addOnFailureListener { e ->
                Log.w("Firestore", "Error al obtener la nota", e)
                onFailure(e)
            }
    }
    // Método para eliminar una nota de Firestore
    fun deleteNoteById(noteId: String, onSuccess: () -> Unit, onFailure: (Exception) -> Unit) {
        val notaRef = db.collection("notas").document(noteId)

        // Eliminar el documento con el ID especificado
        notaRef.delete()
            .addOnSuccessListener {
                onSuccess()  // Callback de éxito
            }
            .addOnFailureListener { e ->
                Log.w("Firestore", "Error al eliminar la nota", e)
                onFailure(e)  // Callback de error
            }
    }

}
