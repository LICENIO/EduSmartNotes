package com.example.edusmartnotes.repository

// Simula un repositorio de usuarios
class UserRepository {

    // Simula la autenticación de usuario
    fun authenticateUser(email: String, password: String): User? {
        // Aquí iría la lógica real de autenticación (API, base de datos, etc.)
        // Simulando autenticación exitosa para un usuario con correo y contraseña predefinidos
        return if (email == "test@example.com" && password == "password123") {
            User(email)  // Simula un usuario autenticado
        } else {
            null  // Si las credenciales son incorrectas, retorna null
        }
    }
}

// Modelo de datos para el usuario autenticado
data class User(val email: String)
