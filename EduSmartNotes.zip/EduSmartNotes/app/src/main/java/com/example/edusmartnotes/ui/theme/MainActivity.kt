package com.example.edusmartnotes.ui.theme

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.navigation.compose.rememberNavController
import com.example.edusmartnotes.navigation.NavGraph
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import com.example.edusmartnotes.viewmodel.NotesViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Recordamos el controlador de navegación
            val navController = rememberNavController()

            // Usamos el MaterialTheme para envolver la UI de la aplicación
            MaterialTheme(
                colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme(),
                typography = MaterialTheme.typography,
                content = {
                    Surface {
                        // Componente que contiene la navegación, pasamos isDarkTheme
                        val notesViewModel: NotesViewModel = viewModel() // Inicializamos el ViewModel
                        NavGraph(navController = navController, isDarkTheme = isSystemInDarkTheme(), viewModel = notesViewModel)
                    }
                }
            )
        }
    }
}
