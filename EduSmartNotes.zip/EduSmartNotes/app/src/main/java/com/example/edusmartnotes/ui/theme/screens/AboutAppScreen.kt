package com.example.edusmartnotes.ui.theme.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun AboutAppScreen(navController: NavController) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally // Centra los elementos
        ) {
            // Icono de retroceso
            Row(modifier = Modifier.fillMaxWidth()) {
                IconButton(
                    onClick = { navController.popBackStack() }
                ) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Volver atrás"
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Título de la pantalla
            Text(
                text = "Acerca de la aplicación",
                style = MaterialTheme.typography.headlineMedium,
                fontSize = 24.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Información de la aplicación
            Text(
                text = "Esta es una aplicación educativa que te permite administrar tus notas, tareas y exámenes de manera eficiente. " +
                        "La aplicación está diseñada para ser fácil de usar, con funcionalidades como: agregar notas, marcar tareas como importantes, " +
                        "y organizar tus actividades escolares. Además, incluye un calendario para gestionar tus horarios y notificaciones para que " +
                        "nunca olvides una tarea importante.",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Justify, // Justifica el texto
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Detalles adicionales
            Text(
                text = "Versión: 1.0.0\nDesarrolladores: EduSmart Team\nContacto: support@edusmart.com",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Botón para regresar
            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(top = 16.dp)
                    .align(Alignment.CenterHorizontally)
            ) {
                Text(text = "Volver")
            }
        }
    }
}
