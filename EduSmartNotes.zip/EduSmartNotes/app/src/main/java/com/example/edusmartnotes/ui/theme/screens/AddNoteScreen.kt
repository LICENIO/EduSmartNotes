package com.example.edusmartnotes.ui.theme.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.edusmartnotes.viewmodel.AddNoteViewModel

@Composable
fun AddNoteScreen(
    viewModel: AddNoteViewModel = viewModel(),
    onNavigateBack: () -> Unit
) {
    var titulo by remember { mutableStateOf("") }
    var contenido by remember { mutableStateOf("") }
    var mensajeExito by remember { mutableStateOf("") }
    var mensajeError by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateBack) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Regresar"
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Agregar Nota",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.weight(1f)
            )
        }
        OutlinedTextField(
            value = titulo,
            onValueChange = { titulo = it },
            label = { Text("Título") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = contenido,
            onValueChange = { contenido = it },
            label = { Text("Contenido") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                viewModel.guardarNota(
                    titulo = titulo,
                    contenido = contenido,
                    onSuccess = {
                        mensajeExito = "Nota guardada exitosamente"
                        titulo = ""
                        contenido = ""
                    },
                    onFailure = { e ->
                        mensajeError = "Error: ${e.localizedMessage}"
                    }
                )
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Guardar Nota")
        }
        Spacer(modifier = Modifier.height(16.dp))
        if (mensajeExito.isNotEmpty()) {
            Text(text = mensajeExito, color = MaterialTheme.colorScheme.primary)
        }
        if (mensajeError.isNotEmpty()) {
            Text(text = mensajeError, color = MaterialTheme.colorScheme.error)
        }
    }
}
