package com.example.edusmartnotes.ui.theme.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.edusmartnotes.viewmodel.NotesViewModel

@Composable
fun EditNoteScreen(viewModel: NotesViewModel, navController: NavHostController, notaId: String) {
    // Obtener la nota a editar por su ID
    val nota = viewModel.getNotaById(notaId)

    if (nota != null) {
        var titulo by remember { mutableStateOf(nota.titulo) }
        var descripcion by remember { mutableStateOf(nota.descripcion) }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            TextField(
                value = titulo,
                onValueChange = { titulo = it },
                label = { Text("Título") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            TextField(
                value = descripcion,
                onValueChange = { descripcion = it },
                label = { Text("Descripción") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    // Crear una nueva nota con los datos actualizados
                    val updatedNota = nota.copy(titulo = titulo, descripcion = descripcion)

                    // Actualizar la nota en el ViewModel
                    viewModel.updateNota(updatedNota)

                    // Volver a la pantalla anterior
                    navController.popBackStack()
                },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text("Guardar")
            }
        }
    } else {
        Text("Nota no encontrada", modifier = Modifier.fillMaxSize(), textAlign = TextAlign.Center)
    }
}
