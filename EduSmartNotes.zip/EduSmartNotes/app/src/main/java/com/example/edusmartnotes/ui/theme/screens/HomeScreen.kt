package com.example.edusmartnotes.ui.theme.screens

import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.edusmartnotes.R

@Preview(showBackground = true)
@Composable
fun PreviewHomeScreen() {
    // Simula el navController en el Preview
    HomeScreen (
        navController = rememberNavController(),
        //onNavigateToLogin = {},
    )
}
@Composable
fun HomeScreen(navController: NavController) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE0F7FA)) // Fondo claro
    ) {
        TopBar(navController)
        ContentGrid(navController)
    }
}

@Composable
fun TopBar(navController: NavController) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF007C92)) // Fondo de la barra superior
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Icono de retroceso
        IconButton(
            onClick = { navController.popBackStack() },
            modifier = Modifier.padding(end = 8.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.ArrowBack,
                contentDescription = "Retroceder",
                tint = Color.White
            )
        }

        Text(
            text = "Edu SmartNotes",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        // Botón de configuración
        IconButton(
            onClick = { navController.navigate("settings") }
        ) {
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = "Configuración",
                tint = Color.White
            )
        }
    }
}

@Composable
fun ContentGrid(navController: NavController) {
    val configuration = LocalConfiguration.current
    val screenWidth = configuration.screenWidthDp.dp

    // Determinar columnas según orientación
    val columns = if (configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) 3 else 2

    // Elementos con imágenes personalizadas
    val items = listOf(
        Pair(R.drawable.agregar, "Agregar Nota"),
        Pair(R.drawable.lista, "Lista de Notas"),
        Pair(R.drawable.importantes, "Notas Importantes"),
        Pair(R.drawable.horario, "Horario"),
 //       Pair(R.drawable.exam, "Exámenes"),
        Pair(R.drawable.acerca, "Acerca de la App")
    )

    // Utilizando ScrollState para la columna
    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        for (rowIndex in items.chunked(columns)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                for ((image, text) in rowIndex) {
                    ImageWithButton(image, text, screenWidth / columns, navController)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun ImageWithButton(imageResId: Int, buttonText: String, width: androidx.compose.ui.unit.Dp, navController: NavController) {
    Column(
        modifier = Modifier
            .width(width)
            .padding(bottom = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = imageResId),
            contentDescription = buttonText,
            modifier = Modifier
                .size(100.dp)
                .padding(bottom = 8.dp)
        )
        Button(
            onClick = {
                when (buttonText) {
                    "Agregar Nota" -> navController.navigate("AddNote")
                    "Lista de Notas" -> navController.navigate("listNotes")
                    "Notas Importantes" -> navController.navigate("notasImportantes")
                    "Horario" -> navController.navigate("horario")
                   // "Exámenes" -> navController.navigate("examenes")
                    "Acerca de la App" -> navController.navigate("acercaDeApp")
                }
            },
            modifier = Modifier.fillMaxWidth(),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(buttonText)
        }
    }
}


