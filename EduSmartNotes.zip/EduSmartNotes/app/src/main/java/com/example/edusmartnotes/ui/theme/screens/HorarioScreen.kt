package com.example.edusmartnotes.ui.theme.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.edusmartnotes.model.Clase
import com.example.edusmartnotes.ui.theme.components.TimePickerDialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.edusmartnotes.viewmodel.HorarioViewModel
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

@Composable
fun HorarioScreen(navController: NavHostController, viewModel: HorarioViewModel = viewModel()) {
    val diasDeSemana = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
    val horario = viewModel.horario

    // Contenedor deslizable verticalmente
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()) // <-- Hace toda la pantalla deslizable
            .padding(16.dp)
    ) {
        // Botón de retroceso
        IconButton(onClick = { navController.popBackStack() }) {
            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Retroceder")
        }

        // Título del horario
        Text(text = "Horario Semanal", style = MaterialTheme.typography.headlineLarge)

        Spacer(modifier = Modifier.height(16.dp))

        // Contenedor deslizable horizontalmente para los días
        LazyRow(modifier = Modifier.fillMaxWidth()) {
            items(diasDeSemana) { dia ->
                DiaColumna(
                    dia = dia,
                    clases = horario.first { it.dia == dia }.clases,
                    onAgregarClase = { diaSeleccionado, clase ->
                        // Agregar clase al horario
                        val horarioDia = horario.first { it.dia == diaSeleccionado }
                        horarioDia.clases.add(clase)
                    }
                )
            }
        }
    }
}

@Composable
fun DiaColumna(dia: String, clases: MutableList<Clase>, onAgregarClase: (String, Clase) -> Unit) {
    var mostrarDialogoAgregar by remember { mutableStateOf(false) }
    var mostrarDialogoEditar by remember { mutableStateOf(false) }
    var claseAEditar by remember { mutableStateOf<Clase?>(null) }

    Column(modifier = Modifier.padding(horizontal = 8.dp).wrapContentWidth()) {
        Text(text = dia, style = MaterialTheme.typography.bodyLarge)

        if (clases.isNotEmpty()) {
            clases.forEach { clase ->
                ClaseItem(
                    clase = clase,
                    onEliminarClase = {
                        clases.remove(clase) // Eliminar clase
                    },
                    onEditarClase = { claseSeleccionada ->
                        claseAEditar = claseSeleccionada
                        mostrarDialogoEditar = true
                    }
                )
            }
        } else {
            Text(text = "No hay clases", color = Color.Gray)
        }

        Button(onClick = { mostrarDialogoAgregar = true }) {
            Text(text = "Agregar Clase")
        }

        if (mostrarDialogoAgregar) {
            AgregarClaseDialog(
                dia = dia,
                onAgregar = { nombre, horaInicio, horaFin ->
                    val nuevaClase = Clase(nombre, horaInicio, horaFin)
                    onAgregarClase(dia, nuevaClase)
                    mostrarDialogoAgregar = false
                },
                onDismiss = { mostrarDialogoAgregar = false }
            )
        }

        // Cuadro de diálogo para editar clase
        if (mostrarDialogoEditar && claseAEditar != null) {
            EditarClaseDialog(
                clase = claseAEditar!!,
                onEditar = { nombre, horaInicio, horaFin ->
                    claseAEditar?.nombre = nombre
                    claseAEditar?.horaInicio = horaInicio
                    claseAEditar?.horaFin = horaFin
                    mostrarDialogoEditar = false
                },
                onDismiss = { mostrarDialogoEditar = false }
            )
        }
    }
}


@Composable
fun ClaseItem(clase: Clase, onEliminarClase: () -> Unit, onEditarClase: (Clase) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .padding(vertical = 4.dp)
            .border(1.dp, Color.Gray)
            .clickable { onEditarClase(clase) } // Hacer la clase clickeable para editar
    ) {
        Row(modifier = Modifier
            .width(250.dp)
            .padding(start = 8.dp)) {

            Text(
                text = "${clase.horaInicio} - ${clase.horaFin} ",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF1E90FF)
            )

            Text(
                text = clase.nombre,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Black,
                softWrap = true
            )
        }

        Spacer(modifier = Modifier.weight(1f))

        IconButton(onClick = { onEliminarClase() }) {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = "Eliminar clase",
                tint = Color.Red
            )
        }
    }
}


@Composable
fun AgregarClaseDialog(
    dia: String,
    onAgregar: (String, String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var nombreClase by remember { mutableStateOf("") }
    var horaInicio by remember { mutableStateOf("") }
    var horaFin by remember { mutableStateOf("") }

    var showTimePickerInicio by remember { mutableStateOf(false) }
    var showTimePickerFin by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { onDismiss() },
        title = { Text(text = "Agregar clase para $dia") },
        text = {
            Column {
                // Campo para el nombre de la clase
                TextField(
                    value = nombreClase,
                    onValueChange = { nombreClase = it },
                    label = { Text(text = "Nombre de la clase") }
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Botón para seleccionar la hora de inicio
                Button(onClick = { showTimePickerInicio = true }) {
                    Text(text = if (horaInicio.isEmpty()) "Seleccionar hora de inicio" else "Inicio: $horaInicio")
                }
                Spacer(modifier = Modifier.height(8.dp))

                // Botón para seleccionar la hora de fin
                Button(onClick = { showTimePickerFin = true }) {
                    Text(text = if (horaFin.isEmpty()) "Seleccionar hora de fin" else "Fin: $horaFin")
                }

                // Mostrar el TimePicker para hora de inicio
                if (showTimePickerInicio) {
                    TimePickerDialog(
                        onTimeSelected = { selectedTime ->
                            horaInicio = selectedTime
                            showTimePickerInicio = false
                        },
                        onDismiss = { showTimePickerInicio = false }
                    )
                }

                // Mostrar el TimePicker para hora de fin
                if (showTimePickerFin) {
                    TimePickerDialog(
                        onTimeSelected = { selectedTime ->
                            horaFin = selectedTime
                            showTimePickerFin = false
                        },
                        onDismiss = { showTimePickerFin = false }
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (nombreClase.isNotEmpty() && horaInicio.isNotEmpty() && horaFin.isNotEmpty()) {
                    onAgregar(nombreClase, horaInicio, horaFin)
                    onDismiss()
                }
            }) {
                Text(text = "Agregar")
            }
        },
        dismissButton = {
            Button(onClick = { onDismiss() }) {
                Text(text = "Cancelar")
            }
        }
    )
}

@Composable
fun EditarClaseDialog(
    clase: Clase,
    onEditar: (String, String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var nombreClase by remember { mutableStateOf(clase.nombre) }
    var horaInicio by remember { mutableStateOf(clase.horaInicio) }
    var horaFin by remember { mutableStateOf(clase.horaFin) }

    var showTimePickerInicio by remember { mutableStateOf(false) }
    var showTimePickerFin by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { onDismiss() },
        title = { Text(text = "Editar clase") },
        text = {
            Column {
                // Campo para el nombre de la clase
                TextField(
                    value = nombreClase,
                    onValueChange = { nombreClase = it },
                    label = { Text(text = "Nombre de la clase") }
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Botón para seleccionar la hora de inicio
                Button(onClick = { showTimePickerInicio = true }) {
                    Text(text = if (horaInicio.isEmpty()) "Seleccionar hora de inicio" else "Inicio: $horaInicio")
                }
                Spacer(modifier = Modifier.height(8.dp))

                // Botón para seleccionar la hora de fin
                Button(onClick = { showTimePickerFin = true }) {
                    Text(text = if (horaFin.isEmpty()) "Seleccionar hora de fin" else "Fin: $horaFin")
                }

                // Mostrar el TimePicker para hora de inicio
                if (showTimePickerInicio) {
                    TimePickerDialog(
                        onTimeSelected = { selectedTime ->
                            horaInicio = selectedTime
                            showTimePickerInicio = false
                        },
                        onDismiss = { showTimePickerInicio = false }
                    )
                }

                // Mostrar el TimePicker para hora de fin
                if (showTimePickerFin) {
                    TimePickerDialog(
                        onTimeSelected = { selectedTime ->
                            horaFin = selectedTime
                            showTimePickerFin = false
                        },
                        onDismiss = { showTimePickerFin = false }
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (nombreClase.isNotEmpty() && horaInicio.isNotEmpty() && horaFin.isNotEmpty()) {
                    onEditar(nombreClase, horaInicio, horaFin)
                    onDismiss()
                }
            }) {
                Text(text = "Editar")
            }
        },
        dismissButton = {
            Button(onClick = { onDismiss() }) {
                Text(text = "Cancelar")
            }
        }
    )
}
