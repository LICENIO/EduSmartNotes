package com.example.edusmartnotes.ui.theme.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.navigation.NavHostController
import com.example.edusmartnotes.model.Nota
import com.example.edusmartnotes.viewmodel.NotesViewModel

@Composable
fun ListNotesScreen(viewModel: NotesViewModel, navController: NavHostController) {
    val notas = viewModel.notas.collectAsState().value
    val error = viewModel.error.collectAsState().value

    Column(modifier = Modifier.fillMaxSize()) {
        // Barra superior personalizada
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .height(56.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(
                    imageVector = Icons.Filled.ArrowBack,
                    contentDescription = "Retroceder"
                )
            }

            Text(
                text = "Lista de Notas",
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f) // Hace que el título ocupe todo el espacio disponible
            )

            IconButton(onClick = { navController.navigate("importantNotes") }) {
                Icon(
                    imageVector = Icons.Filled.Star,
                    contentDescription = "Ver Notas Importantes"
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (error != null) {
            Text(
                text = error,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(notas) { nota ->
                    NoteItem(
                        nota = nota,
                        onClick = {
                            navController.navigate("editNote/${nota.id}")
                        },
                        onImportantClick = {
                            viewModel.toggleImportantStatus(nota.id)
                        },
                        onDeleteClick = {
                            viewModel.deleteNote(nota.id)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun NoteItem(nota: Nota, onClick: () -> Unit, onImportantClick: () -> Unit, onDeleteClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        elevation = CardDefaults.cardElevation(4.dp),
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            Text(text = "Título: ${nota.titulo}", style = MaterialTheme.typography.titleMedium)
            Text(text = "Descripción: ${nota.descripcion}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Fecha: ${nota.fecha}", style = MaterialTheme.typography.bodySmall)

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onImportantClick) {
                    Icon(
                        imageVector = if (nota.importante) Icons.Filled.Star else Icons.Outlined.CheckCircle,  // Cambié ArrowDropDown por StarBorder
                        contentDescription = if (nota.importante) "Desmarcar como importante" else "Marcar como importante"
                    )
                }

                IconButton(onClick = onDeleteClick) {
                    Icon(
                        imageVector = Icons.Filled.Delete,  // Icono de basura
                        contentDescription = "Eliminar nota"
                    )
                }
            }
        }
    }
}
