package com.example.edusmartnotes.ui.theme.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import android.widget.Toast
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalContext
import com.google.firebase.auth.FirebaseAuth

@Preview(showBackground = true)
@Composable
fun PreviewLoginScreen() {
    // Simula el navController en el Preview
    LoginScreen(
        navController = rememberNavController(),
        onNavigateToHome = {},
        onNavigateToRegister = {}
    )
}

@Composable
fun LoginScreen(
    navController: NavController,
    onNavigateToHome: () -> Unit,
    onNavigateToRegister: () -> Unit
) {
    // Estados locales para email, contraseña, carga y errores
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(Color(0xFF007C92))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Botón de retroceso
        IconButton(
            onClick = { navController.popBackStack() },
            modifier = Modifier.align(Alignment.Start)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Volver",
                tint = Color.White
            )
        }

        // Título
        Text(
            text = "Edu SmartNotes",
            fontSize = 32.sp,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 16.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Caja para los inputs
        Box(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .background(Color.White.copy(alpha = 0.7f), shape = RoundedCornerShape(15.dp))
                .padding(16.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Campo de correo electrónico
                TextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Correo Electrónico") },
                    leadingIcon = {
                        Icon(Icons.Default.Email, contentDescription = "Correo Electrónico")
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Campo de contraseña
                TextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Contraseña") },
                    leadingIcon = {
                        Icon(Icons.Default.Lock, contentDescription = "Contraseña")
                    },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Mostrar un indicador de carga si está procesando el inicio de sesión
                if (isLoading) {
                    CircularProgressIndicator(color = Color(0xFF007C92))
                } else {
                    // Botón de iniciar sesión
                    Button(
                        onClick = {
                            isLoading = true
                            error = null
                            if (email.isNotBlank() && password.isNotBlank()) {
                                // Firebase Authentication para iniciar sesión
                                FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                                    .addOnCompleteListener { task ->
                                        isLoading = false
                                        if (task.isSuccessful) {
                                            // Verificar si el correo está verificado
                                            val user = FirebaseAuth.getInstance().currentUser
                                            if (user != null && user.isEmailVerified) {
                                                onNavigateToHome()
                                                Toast.makeText(
                                                    context,
                                                    "Inicio de sesión exitoso",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            } else {
                                                error = "Por favor, verifica tu correo electrónico."
                                            }
                                        } else {
                                            error = "Correo o contraseña incorrectos"
                                        }
                                    }
                            } else {
                                isLoading = false
                                error = "Por favor, completa todos los campos"
                            }
                        },
                        modifier = Modifier.fillMaxWidth(0.6f)
                    ) {
                        Text("Iniciar Sesión")
                    }
                }

                error?.let {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = it,
                        color = Color.Red,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                TextButton(onClick = onNavigateToRegister) {
                    Text("¿No tienes cuenta? Crea una.")
                }

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(onClick = onNavigateToHome) {
                    Text("Ingresar sin cuenta")
                }
            }
        }
    }
}

