package com.example.edusmartnotes.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import com.example.edusmartnotes.model.Nota
import com.example.edusmartnotes.viewmodel.NotesViewModel
import androidx.navigation.NavHostController

@Composable
fun NoteImportScreen(viewModel: NotesViewModel, navController: NavHostController) {
    // Obtenemos las notas importantes desde el ViewModel
    val notasImportantes = viewModel.getImportantNotes()
    val error = viewModel.error.collectAsState().value

    // Diseño general de la pantalla
    Column(modifier = Modifier.fillMaxSize()) {
        // Barra superior personalizada
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .height(56.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Icono de retroceder
            IconButton(onClick = { navController.popBackStack() }) {  // Usamos popBackStack para regresar a la pantalla anterior
                Icon(
                    imageVector = Icons.Filled.ArrowBack, // Icono predefinido de retroceso
                    contentDescription = "Retroceder"
                )
            }

            // Título
            Text(
                text = "Notas Importantes",
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f) // Hace que el título ocupe todo el espacio disponible
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Contenido principal
        if (error != null) {
            Text(
                text = error,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        } else {
            // Si hay notas importantes, se muestran en la lista
            if (notasImportantes.isNotEmpty()) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(notasImportantes) { nota ->
                        // Item de nota con detalles
                        NoteItem(nota = nota)
                    }
                }
            } else {
                // Si no hay notas importantes, mostramos un mensaje
                Text(
                    text = "No tienes notas importantes.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun NoteItem(nota: Nota) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { /* Aquí puedes añadir una acción, como editar la nota */ },
        elevation = CardDefaults.cardElevation(4.dp),
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            // Título y descripción de la nota
            Text(text = "Título: ${nota.titulo}", style = MaterialTheme.typography.titleMedium)
            Text(text = "Descripción: ${nota.descripcion}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Fecha: ${nota.fecha}", style = MaterialTheme.typography.bodySmall)
        }
    }
}
