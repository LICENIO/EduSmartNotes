package com.example.edusmartnotes.ui.theme.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.compose.material.icons.filled.Settings

@Composable
fun SettingsScreen(navController: NavHostController) {
    val scrollState = rememberScrollState()
    var isAccountExpanded by remember { mutableStateOf(false) }
    var isPersonalizeExpanded by remember { mutableStateOf(false) }

    var nombre by remember { mutableStateOf(TextFieldValue("Nombre de Usuario")) }
    var correo by remember { mutableStateOf("correo@example.com") }

    // Control del tema e idioma
    var isDarkTheme by remember { mutableStateOf(false) }
    var selectedLanguage by remember { mutableStateOf("Español") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Retroceder",
                modifier = Modifier
                    .size(24.dp)
                    .clickable {
                        navController.popBackStack() // Acción para retroceder
                    }
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "Configuración",
                style = MaterialTheme.typography.titleLarge
            )
        }

        // Sección Cuenta
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { isAccountExpanded = !isAccountExpanded }
                .padding(8.dp),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Cuenta", style = MaterialTheme.typography.titleMedium)
                if (isAccountExpanded) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = nombre,
                        onValueChange = { nombre = it },
                        label = { Text("Nombre de usuario") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Correo electrónico: $correo", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { isPersonalizeExpanded = !isPersonalizeExpanded }
                .padding(8.dp),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Personalizar", style = MaterialTheme.typography.titleMedium)
                if (isPersonalizeExpanded) {
                    // Selector de tema
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(
                            checked = isDarkTheme,
                            onCheckedChange = { isDarkTheme = it }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isDarkTheme) "Tema Oscuro" else "Tema Claro")
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Selector de idioma
                    Text("Idioma", style = MaterialTheme.typography.bodyLarge)
                    DropdownMenuDemo(selectedLanguage) { newLanguage ->
                        selectedLanguage = newLanguage
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Botón Cerrar sesión
        Button(
            onClick = { /* Lógica de cerrar sesión */ },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
            Text("Cerrar sesión")
        }
    }
}

@Composable
fun DropdownMenuDemo(selectedLanguage: String, onLanguageSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val languages = listOf("Español", "Inglés", "Francés")

    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = selectedLanguage)
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            languages.forEach { language ->
                DropdownMenuItem(
                    text = { Text(language) },
                    onClick = {
                        onLanguageSelected(language)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewSettingsScreen() {
    SettingsScreen(navController = NavHostController(LocalContext.current))
}
