package com.example.edusmartnotes.ui.theme.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.google.firebase.auth.FirebaseAuth
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.rememberNavController

@Preview(showBackground = true)
@Composable
fun PreviewVerificationScreen() {
    VerificationScreen(navController = rememberNavController())
}

@Composable
fun VerificationScreen(navController: NavHostController) {
    val firebaseAuth = FirebaseAuth.getInstance()
    val user = firebaseAuth.currentUser
    val context = LocalContext.current // Para obtener el contexto de Compose

    var isVerified by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(true) } // Indicador de carga
    var verificationError by remember { mutableStateOf<String?>(null) }

    // Verificar el estado de verificación del usuario
    LaunchedEffect(user) {
        user?.reload()?.addOnCompleteListener { task ->
            isLoading = false
            if (task.isSuccessful) {
                isVerified = user?.isEmailVerified == true
            } else {
                verificationError = "Error al obtener estado de verificación."
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Verificación pendiente",
            fontSize = 24.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Mostrar indicador de carga mientras se verifica el estado
        if (isLoading) {
            CircularProgressIndicator()
        } else {
            if (isVerified) {
                Text("¡Tu cuenta ha sido verificada!")
                Button(
                    onClick = { navController.navigate("home") }
                ) {
                    Text("Ir al inicio")
                }
            } else {
                Text("Revisa tu correo para verificar tu cuenta.")
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        user?.sendEmailVerification()
                            ?.addOnCompleteListener { verificationTask ->
                                if (verificationTask.isSuccessful) {
                                    Toast.makeText(context, "Correo de verificación reenviado.", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Error al reenviar correo.", Toast.LENGTH_SHORT).show()
                                }
                            }
                    }
                ) {
                    Text("Reenviar correo de verificación")
                }
            }

            // Mostrar error si existe
            verificationError?.let {
                Spacer(modifier = Modifier.height(16.dp))
                Text(text = it, color = androidx.compose.ui.graphics.Color.Red)
            }
        }
    }
}
