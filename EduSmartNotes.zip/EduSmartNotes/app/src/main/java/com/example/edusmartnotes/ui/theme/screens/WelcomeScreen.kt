package com.example.edusmartnotes.ui.theme.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.edusmartnotes.R
import com.example.edusmartnotes.ui.theme.theme.BluePrimary
import com.example.edusmartnotes.ui.theme.theme.YellowButton

@Preview(showBackground = true)
@Composable
fun PreviewWelcomeScreen() {
    WelcomeScreen(navController = rememberNavController())
}

@Composable
fun WelcomeScreen(navController: NavController) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.LightGray)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Logo
            Image(
                painter = painterResource(id = R.drawable.logo_edusmartnotes),
                contentDescription = "Logo de EduSmartNotes",
                modifier = Modifier
                    .size(150.dp)
                    .padding(bottom = 16.dp)
            )

            Text(
                text = "Bienvenido...!",
                fontSize = 28.sp,
                fontWeight = FontWeight.Medium,
                color = BluePrimary
            )
            Text(
                text = "Edu SmartNotes+",
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                color = BluePrimary,
                modifier = Modifier.padding(top = 8.dp, bottom = 32.dp)
            )

            // Botones
            val buttons = listOf(
                "Login" to "login",
                "Crear cuenta" to "register",
                "Ingresar sin cuenta" to "home"
            )

            buttons.forEachIndexed { index, (text, route) ->
                Button(
                    onClick = { navController.navigate(route) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (index == 2) YellowButton.copy(alpha = 0.0f) else YellowButton
                    ),
                    modifier = Modifier
                        .fillMaxWidth(0.6f)
                        .height(60.dp)
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        text = text,
                        fontSize = 18.sp,
                        color = if (index == 2) BluePrimary else Color.Black
                    )
                }
            }
        }
    }
}
