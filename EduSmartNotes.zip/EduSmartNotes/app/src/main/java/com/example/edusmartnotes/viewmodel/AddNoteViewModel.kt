package com.example.edusmartnotes.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.edusmartnotes.model.Nota
import com.example.edusmartnotes.repository.NoteRepository
import kotlinx.coroutines.launch

class AddNoteViewModel : ViewModel() {
    private val repository = NoteRepository()

    fun guardarNota(
        titulo: String,
        contenido: String,
        onSuccess: () -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val nuevaNota = Nota(titulo = titulo, descripcion = contenido)
        viewModelScope.launch {
            repository.guardarNota(nuevaNota, onSuccess, onFailure)
        }
    }
}
