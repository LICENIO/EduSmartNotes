package com.example.edusmartnotes.viewmodel

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import com.example.edusmartnotes.model.HorarioDia
import com.example.edusmartnotes.model.Clase

class HorarioViewModel : ViewModel() {
    // Lista de horarios persistente
    val horario = mutableStateListOf(
        HorarioDia("Lunes"),
        HorarioDia("Martes"),
        HorarioDia("Miércoles"),
        HorarioDia("Jueves"),
        HorarioDia("Viernes"),
        HorarioDia("Sábado"),
        HorarioDia("Domingo")
    )

    // Función para agregar una clase al día específico
    fun agregarClase(dia: String, nuevaClase: Clase) {
        val diaSeleccionado = horario.firstOrNull { it.dia == dia }
        diaSeleccionado?.clases?.add(nuevaClase)
    }

    // Función para actualizar todas las clases de un día
    fun actualizarClases(dia: String, nuevasClases: List<Clase>) {
        val diaSeleccionado = horario.firstOrNull { it.dia == dia }
        diaSeleccionado?.clases?.clear()  // Limpia las clases actuales
        diaSeleccionado?.clases?.addAll(nuevasClases)  // Agrega las nuevas clases
    }
}
