package com.example.edusmartnotes.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.edusmartnotes.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

// ViewModel para manejar el estado de inicio de sesión
class LoginViewModel(
    private val userRepository: UserRepository // Repositorio para manejar usuarios
) : ViewModel() {

    // Estado del inicio de sesión
    private val _loginState = MutableStateFlow(LoginState()) // Estado mutable que mantiene el estado actual
    val loginState: StateFlow<LoginState> get() = _loginState // Estado accesible como un flujo inmutable

    // Función para realizar el login
    fun login(email: String, password: String) {
        viewModelScope.launch {
            // Inicia el estado de carga
            _loginState.value = _loginState.value.copy(isLoading = true)

            // Simulación de autenticación con el repositorio
            val user = userRepository.authenticateUser(email, password)

            // Actualiza el estado según el resultado de la autenticación
            if (user != null) {
                // Login exitoso, actualiza isLoggedIn a true
                _loginState.value = LoginState(isLoggedIn = true)
            } else {
                // Login fallido, muestra el error
                _loginState.value = LoginState(error = "Credenciales incorrectas.")
            }

            // Finaliza el estado de carga
            _loginState.value = _loginState.value.copy(isLoading = false)
        }
    }
}

data class LoginState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val isLoggedIn: Boolean = false // Esto indica si el login fue exitoso
)
