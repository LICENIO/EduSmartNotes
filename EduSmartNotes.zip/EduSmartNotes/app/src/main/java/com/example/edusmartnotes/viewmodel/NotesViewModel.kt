package com.example.edusmartnotes.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.edusmartnotes.model.Nota
import com.example.edusmartnotes.repository.NoteRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class NotesViewModel : ViewModel() {
    private val repository = NoteRepository()

    // Estado de las notas (flujo reactivo)
    private val _notas = MutableStateFlow<List<Nota>>(emptyList())
    val notas: StateFlow<List<Nota>> = _notas

    // Mensaje de error (opcional)
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    init {
        fetchNotas()
    }

    // Método para cargar todas las notas
    fun fetchNotas() {
        viewModelScope.launch {
            repository.getAllNotes(
                onResult = { listaNotas ->
                    _notas.value = listaNotas
                },
                onFailure = { e ->
                    _error.value = "Error al cargar las notas: ${e.message}"
                }
            )
        }
    }

    // Método para obtener una nota por su ID
    fun getNotaById(id: String): Nota? {
        return _notas.value.find { it.id == id }
    }

    // Método para actualizar una nota
    fun updateNota(updatedNota: Nota) {
        viewModelScope.launch {
            repository.updateNote(
                updatedNota,
                onSuccess = {
                    // Actualizar la lista de notas localmente
                    _notas.value = _notas.value.map { if (it.id == updatedNota.id) updatedNota else it }
                },
                onFailure = { e ->
                    _error.value = "Error al actualizar la nota: ${e.message}"
                }
            )
        }
    }

    // Método para alternar el estado "importante" de una nota
    fun toggleImportantStatus(notaId: String) {
        viewModelScope.launch {
            repository.toggleImportantStatus(notaId,
                onSuccess = {
                    // Después de que se haya marcado o desmarcado como importante,
                    // actualiza la lista de notas localmente
                    _notas.value = _notas.value.map {
                        if (it.id == notaId) it.copy(importante = !it.importante) else it
                    }
                },
                onFailure = { e ->
                    _error.value = "Error al marcar la nota como importante: ${e.message}"
                }
            )
        }
    }

    // Método para obtener solo las notas importantes
    fun getImportantNotes(): List<Nota> {
        return _notas.value.filter { it.importante }
    }

    // UI state management
    private val _uiState = MutableStateFlow<UiState>(UiState.Loading)
    val uiState: StateFlow<UiState> = _uiState

    sealed class UiState {
        object Loading : UiState()
        data class Success(val data: List<Nota>) : UiState()
        data class Error(val message: String) : UiState()
    }
    // Método para eliminar una nota
    fun deleteNote(noteId: String) {
        viewModelScope.launch {
            // Eliminar la nota del repositorio
            repository.deleteNoteById(noteId, onSuccess = {
                // Actualizar la lista de notas localmente después de la eliminación
                _notas.value = _notas.value.filter { it.id != noteId }
            }, onFailure = { e ->
                _error.value = "Error al eliminar la nota: ${e.message}"
            })
        }
    }
}

