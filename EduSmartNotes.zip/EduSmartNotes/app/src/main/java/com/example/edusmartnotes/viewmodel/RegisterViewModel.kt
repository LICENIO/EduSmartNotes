package com.example.edusmartnotes.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class RegisterViewModel : ViewModel() {
    var name by mutableStateOf("")
    var email by mutableStateOf("")
    var password by mutableStateOf("")
    var confirmPassword by mutableStateOf("")
    var error by mutableStateOf("")

    fun register() {
        if (name.isBlank() || email.isBlank() || password.isBlank() || confirmPassword.isBlank()) {
            error = "Por favor, llena todos los campos"
            return
        }

        if (password != confirmPassword) {
            error = "Las contraseñas no coinciden"
            return
        }

        // Aquí puedes agregar lógica para registrar al usuario (por ejemplo, con un repositorio)
        error = "" // Resetear error si todo está bien
    }
}

